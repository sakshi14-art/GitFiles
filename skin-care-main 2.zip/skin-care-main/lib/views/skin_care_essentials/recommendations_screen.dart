import 'package:flutter/material.dart';

class RecommendationsScreen extends StatelessWidget {
  const RecommendationsScreen({super.key});

  // Example products for demonstration
  List<Product> getRecommendedProducts() {
    return [
      Product(
        name: 'Hydrating Serum',
        description: 'A serum that deeply hydrates and revitalizes the skin.',
        benefits: 'Increases hydration, improves skin texture, and reduces fine lines.',
        instructions:
            'Apply a few drops to the face and neck after cleansing. Gently massage in upward motions until absorbed.',
        imageUrl: 'assets/images/serum.webp', // Replace with an actual image URL
      ),
      Product(
        name: 'Moisturizing Cream',
        description: 'A rich cream that provides long-lasting hydration and nourishment.',
        benefits: 'Keeps skin hydrated all day, softens and smooths rough patches.',
        instructions:
            'Apply to face and neck in the morning and evening after serum. Gently massage in until fully absorbed.',
        imageUrl: 'assets/images/mcream.jpg', // Replace with an actual image URL
      ),
      Product(
        name: 'Gentle Cleanser',
        description: 'A mild cleanser that removes impurities without stripping moisture.',
        benefits: 'Cleanses skin gently, maintains natural moisture balance.',
        instructions:
            'Wet face with lukewarm water. Apply a small amount to the face, lather, and rinse thoroughly. Use morning and evening.',
        imageUrl: 'assets/images/gc.jpeg', // Replace with an actual image URL
      ),
      Product(
        name: 'Vitamin C Serum',
        description: 'An antioxidant-rich serum that brightens and protects the skin.',
        benefits: 'Reduces dark spots, evens skin tone, and enhances radiance.',
        instructions: 'Apply a few drops to clean, dry skin before moisturizing. Use in the morning for best results.',
        imageUrl: 'assets/images/vitaminc.webp', // Replace with an actual image URL
      ),
      Product(
        name: 'Sunscreen SPF 30',
        description: 'A broad-spectrum sunscreen that protects against UVA and UVB rays.',
        benefits: 'Prevents sunburn and premature aging caused by UV exposure.',
        instructions:
            'Apply generously to all exposed skin 15 minutes before sun exposure. Reapply every 2 hours or after swimming.',
        imageUrl: 'assets/images/ss.webp', // Replace with an actual image URL
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Recommendations'),
      ),
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: getRecommendedProducts().length,
          itemBuilder: (context, index) {
            final product = getRecommendedProducts()[index];
            return ProductDetailScreen(product: product);
          },
        ),
      ),
    );
  }
}

class ProductDetailScreen extends StatelessWidget {
  final Product product;

  const ProductDetailScreen({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      margin: EdgeInsets.symmetric(vertical: 15),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              product.imageUrl,
              height: 200,
              width: 200,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),
            const Text(
              'Description:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(product.description, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            const Text(
              'Benefits:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(product.benefits, style: const TextStyle(fontSize: 16)),
            const SizedBox(height: 16),
            const Text(
              'Instructions:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Text(product.instructions, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }
}

class Product {
  final String name;
  final String description;
  final String benefits;
  final String instructions;
  final String imageUrl;

  Product({
    required this.name,
    required this.description,
    required this.benefits,
    required this.instructions,
    required this.imageUrl,
  });
}
