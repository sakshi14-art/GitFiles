import 'package:flutter/material.dart';

class ExercisesScreen extends StatelessWidget {
  const ExercisesScreen({super.key});

  // Example exercises for demonstration
  List<Exercise> getExercises() {
    return [
      Exercise(
        name: 'Push-ups',
        description: 'A great exercise for building upper body strength.',
        benefits: 'Strengthens chest, shoulders, and triceps.',
        instructions:
            '1. Start in a plank position with arms slightly wider than shoulder-width apart.\n2. Lower your body until your chest nearly touches the floor.\n3. Push yourself back up to the starting position.',
        imageUrl: 'assets/images/pushups.jpg', // Replace with an actual image URL
      ),
      Exercise(
        name: 'Squats',
        description: 'Targets the lower body and helps in strengthening legs.',
        benefits: 'Strengthens quads, hamstrings, and glutes.',
        instructions:
            '1. Stand with feet shoulder-width apart.\n2. Bend your knees and lower your hips as if sitting in a chair.\n3. Keep your back straight and return to the starting position.',
        imageUrl: 'assets/images/squats.jpg', // Replace with an actual image URL
      ),
      Exercise(
        name: 'Plank',
        description: 'An excellent core strengthening exercise.',
        benefits: 'Strengthens core, shoulders, and back.',
        instructions:
            '1. Start in a push-up position but with your weight on your forearms.\n2. Keep your body in a straight line from head to heels.\n3. Hold this position for as long as possible.',
        imageUrl: 'assets/images/plank.jpg', // Replace with an actual image URL
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Exercises'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ExerciseList(exercises: getExercises()),
      ),
    );
  }
}

class ExerciseList extends StatelessWidget {
  final List<Exercise> exercises;

  const ExerciseList({super.key, required this.exercises});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: exercises.length,
      itemBuilder: (context, index) {
        final exercise = exercises[index];
        return Card(
            elevation: 5,
            margin: const EdgeInsets.symmetric(vertical: 8),
            child: Padding(
              padding: const EdgeInsets.all(15),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Image.asset(
                        exercise.imageUrl,
                        width: 100,
                        height: 100,
                        fit: BoxFit.cover,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(exercise.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                            const SizedBox(height: 5),
                            Text(exercise.description),
                          ],
                        ),
                      )
                    ],
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Benefits:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(exercise.benefits, style: const TextStyle(fontSize: 16)),
                  const SizedBox(height: 16),
                  const Text(
                    'Instructions:',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Text(exercise.instructions, style: const TextStyle(fontSize: 16)),
                ],
              ),
            ));
      },
    );
  }
}

class Exercise {
  final String name;
  final String description;
  final String benefits;
  final String instructions;
  final String imageUrl;

  Exercise({
    required this.name,
    required this.description,
    required this.benefits,
    required this.instructions,
    required this.imageUrl,
  });
}
