import 'package:flutter/material.dart';

class WaterTrackerScreen extends StatefulWidget {
  const WaterTrackerScreen({super.key});

  @override
  _WaterTrackerScreenState createState() => _WaterTrackerScreenState();
}

class _WaterTrackerScreenState extends State<WaterTrackerScreen> {
  int _waterIntake = 0;
  final int _dailyGoal = 2000; // Example goal: 2000 ml
  final List<int> _dailyLog = []; // Log of water intake

  void _addWater(int amount) {
    setState(() {
      _waterIntake += amount;
      _dailyLog.add(amount); // Add the daily intake to the log
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Water Tracker'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Description
            const Text(
              'Why Staying Hydrated is Important:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            const Text(
              'Water is essential for your body’s overall health and well-being. Staying hydrated helps maintain the balance of bodily fluids, regulates body temperature, and supports various functions including digestion, absorption, and circulation. Proper hydration can also improve energy levels, cognitive function, and skin health.',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            // Daily Goal
            Text(
              'Daily Water Goal: $_dailyGoal ml',
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            // Current Intake
            Text(
              'Current Intake: $_waterIntake ml',
              style: const TextStyle(fontSize: 20),
            ),
            const SizedBox(height: 20),
            // Add Water Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () => _addWater(250),
                  child: const Text('Add 250 ml'),
                ),
                const SizedBox(width: 10),
                ElevatedButton(
                  onPressed: () => _addWater(500),
                  child: const Text('Add 500 ml'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            // Water Intake Log
            const Text(
              'Water Intake Log:',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _dailyLog.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text('${_dailyLog[index]} ml'),
                    leading: const Icon(Icons.local_drink),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
