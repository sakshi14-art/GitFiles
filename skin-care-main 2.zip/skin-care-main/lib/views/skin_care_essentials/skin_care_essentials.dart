import 'package:flutter/material.dart';
import 'package:skin_care/views/skin_care_essentials/excercise_screen.dart';
import 'package:skin_care/views/skin_care_essentials/recommendations_screen.dart';
import 'package:skin_care/views/skin_care_essentials/water_tracker_screen.dart';

class SkinCareEssentials extends StatefulWidget {
  const SkinCareEssentials({super.key});

  @override
  State<SkinCareEssentials> createState() => _SkinCareEssentialsState();
}

class _SkinCareEssentialsState extends State<SkinCareEssentials> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Skin Care Essentials'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            _buildCard(
              context,
              'Exercises',
              'Stay fit and healthy with these exercises!',
              Icons.fitness_center,
              const ExercisesScreen(),
            ),
            const SizedBox(height: 20),
            _buildCard(
              context,
              'Recommendations',
              'Discover products tailored for your skin type.',
              Icons.recommend,
              const RecommendationsScreen(),
            ),
            const SizedBox(height: 20),
            _buildCard(
              context,
              'Water Tracker',
              'Keep track of your daily water intake.',
              Icons.water,
              const WaterTrackerScreen(),
            ),
            SizedBox(height: 75),
            Image.asset(
              "assets/images/logo.png",
              height: 175,
              width: 175,
              fit: BoxFit.cover,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard(BuildContext context, String title, String subtitle, IconData icon, Widget page) {
    return Card(
      elevation: 5,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        leading: Icon(icon, size: 40, color: Colors.blue),
        title: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          );
        },
      ),
    );
  }
}
