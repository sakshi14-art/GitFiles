import 'dart:ui';

class AppColors {
  static Color black = const Color(0xFF1D1D1D);
  static Color cream = const Color(0xFFEBEEEE);
  static Color yellow = const Color(0xFFF4F031);
  static Color pink = const Color(0xFFFB8CD2);
  static Color white = const Color(0x0fffffff);
}
