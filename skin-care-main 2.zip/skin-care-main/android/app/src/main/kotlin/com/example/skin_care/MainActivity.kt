package com.example.skin_care

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
